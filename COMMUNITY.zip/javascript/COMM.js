$("#typed").typed({
    strings: [
        "Hello, there.",
        "Website Under Construction!",
        "Everything Is Fine :)"
    ],
    typeSpeed: 20,
    startDelay: 0,
    backSpeed: 20,
    backDelay: 1000,
    loop: true,
    cursorChar: "|",
    contentType: "html"
});
